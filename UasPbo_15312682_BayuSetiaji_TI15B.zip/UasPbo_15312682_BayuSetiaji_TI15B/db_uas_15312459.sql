/*
SQLyog Enterprise - MySQL GUI v7.14 
MySQL - 5.0.51b-community-nt-log : Database - db_uas_15312459
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_uas_15312459` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_uas_15312459`;

/*Table structure for table `tbl_pinjam` */

DROP TABLE IF EXISTS `tbl_pinjam`;

CREATE TABLE `tbl_pinjam` (
  `id` int(6) NOT NULL auto_increment,
  `nama` varchar(30) default NULL,
  `nope` varchar(15) default NULL,
  `barang` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `tbl_pinjam` */

insert  into `tbl_pinjam`(`id`,`nama`,`nope`,`barang`) values (1,'Ridwan Pinanjar',NULL,'Sepatu');

/*Table structure for table `tbl_teman` */

DROP TABLE IF EXISTS `tbl_teman`;

CREATE TABLE `tbl_teman` (
  `id` int(6) NOT NULL auto_increment,
  `nama` varchar(30) default NULL,
  `nope` varchar(15) default NULL,
  `email` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `tbl_teman` */

insert  into `tbl_teman`(`id`,`nama`,`nope`,`email`) values (1,'Ridwan Pinanjar','085664902126','ridwanpinanjar@yahoo.com'),(3,'Rifky','08987826283932','rifky@yahoo.com'),(4,'indah','085767892527','indahnuri@yahoo.com'),(5,'Andri','0897782829292','andri@yahoo.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
